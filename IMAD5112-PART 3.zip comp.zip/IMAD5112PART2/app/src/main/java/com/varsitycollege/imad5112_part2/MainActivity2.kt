//www.youtube.com. (n.d.). Creating Simple Calculator App (Android Studio / Kotlin ) Beginner Level 2023. [online] Available at: https://youtu.be/2BiDtcUiBu8?si=3FTJimElOL7ipGq5 [Accessed 21 Nov. 2023].
//
//‌
package com.varsitycollege.imad5112_part2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.annotation.SuppressLint
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        class MainActivity : AppCompatActivity() {

            private var numberCount = 0
            private var numbers = IntArray(10)
            private var minNumber = Int.MAX_VALUE
            private var maxNumber = Int.MIN_VALUE

            override fun onCreate(savedInstanceState: Bundle?) {
                super.onCreate(savedInstanceState)
                setContentView(R.layout.activity_main)

                // Handle click events for buttons
                findViewById<Button>(R.id.calculate_average_button).setOnClickListener { calculateAverage() }
                findViewById<Button>(R.id.find_min_max_button).setOnClickListener { findMinMax() }
                findViewById<Button>(R.id.clear_button).setOnClickListener { clearArray() }
            }

            private fun calculateAverage() {
                var sum = 0
                for (number in numbers) {
                    sum += number
                }
                val average = sum.toDouble() / numberCount
                Toast.makeText(this, "Average: $average", Toast.LENGTH_SHORT).show()
            }

            private fun findMinMax() {
                for (number in numbers) {
                    if (number < minNumber) {
                        minNumber = number
                    }
                    if (number > maxNumber) {
                        maxNumber = number
                    }
                }
                Toast.makeText(this, "Min: $minNumber, Max: $maxNumber", Toast.LENGTH_SHORT).show()
            }

            private fun clearArray() {
                numbers = IntArray(10)
                numberCount = 0
                minNumber = Int.MAX_VALUE
                maxNumber = Int.MIN_VALUE
                Toast.makeText(this, "Array cleared", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
package com.example.calculatorapp7

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {

    private val maxNumbers = 10
    private val numbersArray = IntArray(maxNumbers)
    private var currentCount = 0

    private lateinit var textViewDisplay: TextView
    private lateinit var editTextNumber: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        // Initialize references to UI components
        val buttonAdd: Button = findViewById(R.id.buttonAdd)
        val buttonClear: Button = findViewById(R.id.buttonClear)
        val buttonMAM: Button = findViewById(R.id.buttonMAM)
        val buttonAverage: Button = findViewById(R.id.buttonAverage)
        val editTextNumber2: EditText = findViewById(R.id.editTextNumber2)

        // Initialize class-level properties
        textViewDisplay = findViewById(R.id.DisplayTextView)
        editTextNumber = findViewById(R.id.editTextNumber)

        // Add click listeners for the buttons
        buttonAdd.setOnClickListener {
            if (currentCount < maxNumbers) {
                val enteredNumber = editTextNumber2.text.toString().toIntOrNull()

                if (enteredNumber != null) {
                    numbersArray[currentCount] = enteredNumber
                    currentCount++
                    updateDisplay()
                }
            }
        }

        buttonClear.setOnClickListener {
            clearArray()
            updateDisplay()
        }

        buttonMAM.setOnClickListener {
            findMinMax()
        }

        buttonAverage.setOnClickListener {
            calculateAverage()
        }
    }

    private fun clearArray() {
        for (i in 0 until maxNumbers) {
            numbersArray[i] = 0
        }
        currentCount = 0
    }

    private fun updateDisplay() {
        textViewDisplay.text = "Numbers entered: ${numbersArray.copyOfRange(0, currentCount).contentToString()}"
    }

    private fun calculateAverage() {
        val sum = numbersArray.copyOfRange(0, currentCount).sum()
        val average = if (currentCount > 0) sum.toDouble() / currentCount else 0.0
        editTextNumber.setText("Average: $average")
    }

    private fun findMinMax() {
        val min = numbersArray.copyOfRange(0, currentCount).minOrNull()
        val max = numbersArray.copyOfRange(0, currentCount).maxOrNull()
        editTextNumber.setText("Min: $min, Max: $max")
    }
}

//Reference list//

//https://youtu.be/yFLUg0Rfhkk?feature=shared
//https://youtu.be/JBLJxSvb_Rw?feature=shared
//https://youtu.be/pKvqFaiyFBw?feature=shared
package com.example.calculatorapp7

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Initialize references to UI components
    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView
    private lateinit var buttonPlus: Button
    private lateinit var buttonMinus: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var buttonClear: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonStat = findViewById<Button>(R.id.buttonSTAT)
        buttonStat.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }

        // Initialize UI components
        num1EditText = findViewById(R.id.num1editTextNumber)
        num2EditText = findViewById(R.id.num2editTextNumber)
        resultTextView = findViewById(R.id.editTextNumber)
        buttonPlus = findViewById(R.id.buttonPlus)
        buttonMinus = findViewById(R.id.buttonMinus)
        buttonMultiply = findViewById(R.id.buttonMultiply)
        buttonDivide = findViewById(R.id.buttonDivide)
        buttonClear = findViewById(R.id.buttonClear)

        // Set click listeners for operation buttons
        buttonPlus.setOnClickListener {
            performOperation("+")
        }

        buttonMinus.setOnClickListener {
            performOperation("-")
        }

        buttonMultiply.setOnClickListener {
            performOperation("*")
        }

        buttonDivide.setOnClickListener {
            performOperation("/")
        }

        // Set click listener for clear button
        val clearButton = findViewById<Button>(R.id.buttonClear)
        clearButton.setOnClickListener {
            num1EditText.setText("")
            num2EditText.setText("")
            resultTextView.text = ""
        }
    }

    private fun performOperation(operationSymbol: String) {
        val num1 = num1EditText.text.toString().toIntOrNull()
        val num2 = num2EditText.text.toString().toIntOrNull()

        if (num1 != null && num2 != null) {
            val result = when (operationSymbol) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "*" -> num1 * num2
                "/" -> if (num2 != 0) num1 / num2.toDouble() else Double.NaN
                else -> throw IllegalArgumentException("Invalid operation symbol")
            }

            resultTextView.text = result.toString()
        }
    }
}

//Reference list//

//https://youtu.be/yFLUg0Rfhkk?feature=shared
//https://youtu.be/JBLJxSvb_Rw?feature=shared
//https://youtu.be/pKvqFaiyFBw?feature=shared